# 📊 System Architecture Overview

## User Journey

```
┌─────────────────────────────────────────────────────────────┐
│                    SPACECRAFTS FURNITURE                     │
└─────────────────────────────────────────────────────────────┘

1. USER VISITS WEBSITE
   │
   ├─→ Not signed in? → Click "Sign in with Google"
   │   └─→ Redirected to /login
   │       └─→ Google OAuth Dialog
   │           └─→ User approves
   │               └─→ Redirected to /auth/callback
   │                   └─→ Profile auto-created in Supabase
   │                       └─→ Redirected to /account
   │
   └─→ Browse products
       └─→ Click product → View product page
           │
           ├─→ TAB 1: DESCRIPTION
           │   Shows product details
           │
           ├─→ TAB 2: SPECIFICATIONS
           │   Shows dimensions, material, warranty
           │
           ├─→ TAB 3: REVIEWS
           │   ├─→ ReviewForm (if signed in)
           │   │   ├─→ Select rating (⭐⭐⭐⭐⭐)
           │   │   ├─→ Enter title
           │   │   ├─→ Enter details
           │   │   └─→ Submit
           │   │       └─→ ReviewsList updates
           │   │
           │   └─→ ReviewsList
           │       ├─→ Sort by: Recent/Helpful/Highest/Lowest
           │       ├─→ Display reviews with rating
           │       ├─→ Vote helpful/unhelpful
           │       └─→ Load more reviews
           │
           └─→ TAB 4: Q&A
               ├─→ "+ Ask a Question" button
               │   ├─→ Enter question
               │   └─→ Submit
               │       └─→ Question appears immediately
               │
               └─→ Question accordion
                   ├─→ Show answered questions first
                   ├─→ Expand to see answer
                   └─→ Track view count
```

---

## Admin Journey

```
┌─────────────────────────────────────────────────────────────┐
│                    ADMIN DASHBOARD                           │
│                   /admin/reviews                             │
└─────────────────────────────────────────────────────────────┘

Admin (user with @admin email) logs in

REVIEWS TAB
│
├─→ See all reviews with status badges
│   ├─→ PENDING (orange) → Approve/Reject/Delete
│   ├─→ APPROVED (green) → Delete only
│   └─→ REJECTED (red) → Delete only
│
└─→ Click to expand review
    ├─→ See full review details
    ├─→ Click "Approve" → Updates status to approved
    ├─→ Click "Reject" → Updates status to rejected
    └─→ Click "Delete" → Removes review

Q&A TAB
│
├─→ See all questions with status badges
│   ├─→ UNANSWERED (yellow) → Reply
│   └─→ ANSWERED (green) → View only
│
└─→ For unanswered questions
    ├─→ Click "Reply" button
    ├─→ Enter answer in textarea
    ├─→ Click "Post Answer"
    │   └─→ Answer saved to database
    │       └─→ Appears on product page
    └─→ For answered questions
        ├─→ Can hide questions (removes from public view)
        └─→ Answers are final
```

---

## Database Architecture

```
┌─────────────────────────────────────────────────────┐
│                  SUPABASE DATABASE                   │
└─────────────────────────────────────────────────────┘

PROFILES TABLE
├─ id (UUID - from Auth)
├─ email ✓
├─ full_name ✓ (from Google)
├─ avatar_url ✓ (from Google)
├─ phone
├─ address
├─ city, state, postal_code, country
└─ created_at

PRODUCTS TABLE (existing)
├─ id
├─ name
├─ slug
├─ price
├─ rating (auto-updated)
├─ review_count (auto-updated)
└─ ...

REVIEWS TABLE
├─ id
├─ product_id → PRODUCTS
├─ user_id → PROFILES
├─ rating (1-5)
├─ title
├─ body
├─ helpful_count (auto-updated)
├─ unhelpful_count (auto-updated)
├─ verified_purchase
├─ status (pending/approved/rejected)
├─ created_at
└─ UNIQUE(product_id, user_id)

REVIEW_VOTES TABLE
├─ id
├─ review_id → REVIEWS
├─ user_id → PROFILES
├─ vote_type (helpful/unhelpful)
└─ UNIQUE(review_id, user_id)

PRODUCT_QA TABLE
├─ id
├─ product_id → PRODUCTS
├─ user_id → PROFILES
├─ question
├─ answer (nullable)
├─ answer_by → PROFILES (admin user)
├─ is_helpful_for_others
├─ views_count
├─ status (published/hidden)
├─ created_at
└─ answered_at (nullable)

RLS POLICIES
├─ REVIEWS: Anyone can read approved
│           Users can create/edit own
│           Admin can manage all
│
├─ PRODUCT_QA: Anyone can read published
│              Users can create own
│              Admin can reply/hide
│
└─ REVIEW_VOTES: Users can create own votes
                 Anyone can read
```

---

## API Flow

```
FRONTEND REQUEST
│
├─→ POST /api/reviews/[productId]
│   ├─ Body: { title, body, rating }
│   ├─ Header: Authorization: Bearer {token}
│   └─→ Backend validates user
│       ├─→ Check user authenticated
│       ├─→ Check hasn't reviewed this product
│       ├─→ Insert review with status='pending'
│       └─→ Return review object
│
├─→ GET /api/reviews/[productId]
│   ├─ Query: limit=10&offset=0
│   └─→ Fetch approved reviews only
│       └─→ Return paginated reviews
│
├─→ POST /api/qa/[productId]
│   ├─ Body: { question }
│   ├─ Header: Authorization: Bearer {token}
│   └─→ Backend validates
│       ├─→ Check user authenticated
│       ├─→ Validate question length
│       ├─→ Insert question with status='published'
│       └─→ Return question object
│
└─→ GET /api/qa/[productId]
    ├─ Query: limit=10&offset=0
    └─→ Fetch all published Q&A
        └─→ Return questions (answered first)
```

---

## Authentication Flow

```
USER CLICKS "SIGN IN WITH GOOGLE"
│
├─→ Browser: Redirect to Google OAuth
│
├─→ User: Approves in Google dialog
│
├─→ Google: Redirect to /auth/callback with code
│   │
│   └─→ Supabase: Exchanges code for session
│
├─→ AuthProvider: Checks session
│   │
│   ├─→ Get user from auth
│   │
│   ├─→ Fetch profile from `profiles` table
│   │
│   └─→ If not exists: Create profile
│       ├─ id = user.id
│       ├─ email = user.email
│       ├─ full_name = user.user_metadata.full_name
│       └─ avatar_url = user.user_metadata.avatar_url
│
└─→ User now authenticated
    ├─ Can submit reviews
    ├─ Can post questions
    ├─ Can vote helpful/unhelpful
    └─ Can access /account and /orders
```

---

## Component Hierarchy

```
ROOT LAYOUT
│
└─→ <AuthProvider>
    │
    ├─→ <Header>
    │   ├─ useAuth() → Shows user name / Sign out
    │   └─ Navigation links
    │
    ├─→ <ProductDetailClient>
    │   │
    │   ├─→ Product images, price, add to cart
    │   │
    │   └─→ Tabs Section
    │       ├─ Description tab
    │       ├─ Specifications tab
    │       ├─ Reviews tab
    │       │  ├─→ <ReviewForm />
    │       │  │  ├─ useAuth() → Check signed in
    │       │  │  └─ POST /api/reviews/[id]
    │       │  │
    │       │  └─→ <ReviewsList />
    │       │     ├─ GET /api/reviews/[id]
    │       │     └─ Display sorted reviews
    │       │
    │       └─ Q&A tab
    │          └─→ <ProductQA />
    │             ├─ GET /api/qa/[id]
    │             ├─ POST /api/qa/[id]
    │             └─ Accordion display
    │
    ├─→ <AdminPanel> (at /admin/reviews)
    │   ├─ useAuth() → Check @admin email
    │   ├─ Fetch from reviews table
    │   ├─ Update reviews status
    │   ├─ Reply to questions
    │   └─ Hide/show questions
    │
    ├─→ <Footer>
    │
    └─→ Global providers
        ├─ Supabase client
        └─ Auth context
```

---

## Data Flow Example: Submit Review

```
USER SUBMITS REVIEW
│
1. ReviewForm component
   ├─ Get auth token from useAuth()
   ├─ Validate form data
   │
   └─ POST /api/reviews/[productId]
      Headers: { Authorization: Bearer {token} }
      Body: { title, body, rating }
      │
2. API Route (/api/reviews/[id]/route.js)
   ├─ Extract token from header
   ├─ Verify user with Supabase
   ├─ Check user hasn't reviewed this product
   ├─ Insert into reviews table:
   │  - user_id = user.id
   │  - product_id = id from URL
   │  - title, body, rating from request
   │  - status = 'pending'
   │
   └─ Return review object
      │
3. ReviewForm component
   ├─ Show success message
   ├─ Clear form
   ├─ Call onReviewSubmitted()
   │
4. ReviewsList component
   ├─ Receives refresh signal
   ├─ Refetch reviews from API
   ├─ Show updated list
   │
5. Database
   ├─ Review inserted with pending status
   ├─ Email notification to admin (optional)
   │
6. Admin Reviews
   ├─ Sees new pending review
   ├─ Clicks "Approve"
   ├─ Status updated to "approved"
   │
7. ReviewsList component
   ├─ Refetch approved reviews
   ├─ Review now visible to all users
   │
└─ COMPLETE ✅
```

---

## Security Model

```
ROW LEVEL SECURITY (RLS)
│
├─→ PROFILES
│   ├─ Authenticated users can read public data
│   └─ Users can only UPDATE their own profile
│
├─→ REVIEWS
│   ├─ Anyone can SELECT approved reviews
│   ├─ Authenticated users can INSERT own reviews
│   ├─ Users can UPDATE/DELETE own reviews
│   └─ Admins can UPDATE all reviews
│
├─→ PRODUCT_QA
│   ├─ Anyone can SELECT published Q&A
│   ├─ Authenticated users can INSERT questions
│   └─ Admins can UPDATE (reply/hide)
│
├─→ REVIEW_VOTES
│   ├─ Anyone can SELECT votes
│   ├─ Authenticated users can INSERT own votes
│   └─ Prevent duplicate votes with UNIQUE constraint
│
└─ SERVICE ROLE KEY
   ├─ Used only in /api/* routes
   ├─ Never exposed in frontend code
   ├─ Allows admin operations
   └─ Protected by middleware authentication
```

---

## Error Handling

```
AUTHENTICATION ERRORS
│
├─→ No token → 401 Unauthorized
├─→ Invalid token → 401 Unauthorized
├─→ Session expired → 401 Unauthorized
│
└─→ Frontend shows: "Please sign in to continue"

VALIDATION ERRORS
│
├─→ Missing required fields → 400 Bad Request
├─→ Invalid rating (not 1-5) → 400 Bad Request
├─→ Question too short → 400 Bad Request
│
└─→ Frontend shows: User-friendly error message

DATABASE ERRORS
│
├─→ RLS violation → 403 Forbidden
├─→ Foreign key error → 400 Bad Request
├─→ Unique constraint → 409 Conflict
│
└─→ Frontend shows: Error to user or retry

API ERRORS
│
├─→ 5xx errors → Show "Something went wrong"
├─→ Network errors → Show "Connection error"
│
└─→ Retry mechanism + error boundary
```

---

## Deployment Checklist

```
BEFORE GOING LIVE
│
├─ [ ] Google OAuth production credentials
├─ [ ] Supabase production database
├─ [ ] Environment variables updated
├─ [ ] NEXT_PUBLIC_SITE_URL = your domain
├─ [ ] RLS policies verified
├─ [ ] Email notifications configured (optional)
├─ [ ] Admin user created (with @admin email)
├─ [ ] Testing completed
├─ [ ] Error logging setup (Sentry, etc.)
└─ [ ] Database backups configured
```

---

## Performance Optimization

```
QUERIES OPTIMIZED WITH
│
├─ Pagination (limit/offset)
├─ Indexes on frequently searched columns
│  - idx_reviews_product
│  - idx_reviews_status
│  - idx_product_qa_product
│
├─ Lazy loading in ReviewsList
├─ Accordion prevents rendering all Q&A at once
│
└─ Database triggers auto-calculate
   - product rating
   - helpful counts
   - review counts
```

---

This architecture ensures:
✅ Security with RLS policies
✅ Scalability with pagination
✅ User-friendly interface
✅ Admin management capabilities
✅ Real-time data updates

