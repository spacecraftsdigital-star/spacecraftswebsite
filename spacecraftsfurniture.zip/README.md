# Spacecrafts Furniture - Next.js + Supabase + Stripe

This repository is a production-ready starter e-commerce platform for a furniture store built with Next.js App Router, Supabase (DB, Auth, Storage), and Stripe.

Quick start

1. Copy `.env.example` to `.env.local` and fill in Supabase and Stripe keys.
2. Install deps: `npm install`
3. Run dev: `npm run dev`

Supabase setup

- Create a Supabase project.
- Create a Storage bucket named `product-images`.
- Enable Google OAuth in Supabase Auth and set redirect to `https://your-site.vercel.app/api/auth/callback` (or local callback).
- Run the SQL in `sql/schema.sql` to create tables and seed mock data.

Vercel Deployment

- Add environment variables from `.env.example` in Vercel project settings.
- Set Next.js build command and root appropriately.

Files of interest

- `app/` - Next.js App Router pages
- `lib/supabaseClient.js` - Supabase client helper
- `lib/stripe.js` - Stripe helper
- `app/api/create-checkout-session/route.js` - Server API to create Stripe Checkout
- `sql/schema.sql` - Database schema + mock data

Google Ads / Server-side conversions

- This repo includes a scaffold for server-side conversion uploads to Google Ads and GA4:
	- `lib/googleAds.js` — scaffold helper that exchanges a refresh token for an access token and attempts to call the Google Ads conversion upload endpoint. It uses placeholder env vars: `GOOGLE_ADS_DEVELOPER_TOKEN`, `GOOGLE_ADS_CLIENT_ID`, `GOOGLE_ADS_CLIENT_SECRET`, `GOOGLE_ADS_REFRESH_TOKEN`, `GOOGLE_ADS_CUSTOMER_ID` and `GOOGLE_ADS_CONVERSION_RESOURCE` (resource name of conversionAction).
	- `app/api/track/google-ads/route.js` — API route that accepts conversion payload and forwards it to the scaffold helper.
	- `lib/analytics.js` — GA4 Measurement Protocol helper (uses `GA4_MEASUREMENT_ID` and `GA4_API_SECRET`).
	- `app/api/track/conversion/route.js` — central conversion endpoint that triggers GTM server POST, GA4 MP, SendGrid email, and (if available) Google Ads upload when a `gclid` is provided.

Notes about Google Ads UploadConversions

- Uploading conversions to Google Ads requires a valid developer token and OAuth2 credentials (client ID/secret + refresh token). You must request a developer token and enable the Google Ads API for your account.
- The scaffolded helper attempts to obtain an access token via OAuth2 refresh token and then POSTs to the Google Ads upload endpoint. The exact upload endpoint and request schema may vary by API version; treat this as a starting point and replace with your exact conversionAction resource name.
- For most projects, using a GTM Server Container (set `GTM_SERVER_URL`) + GA4 server-side events is simpler and recommended.

