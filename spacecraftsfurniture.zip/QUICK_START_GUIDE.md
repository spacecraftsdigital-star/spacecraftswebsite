# ⚡ Quick Start Guide - 5 Minutes Setup

## Step 1: Database Schema (2 minutes)

1. Open your Supabase dashboard
2. Go to **SQL Editor** → **New Query**
3. Open file: `sql/auth_reviews_qa_schema.sql`
4. Copy ALL content
5. Paste into Supabase query editor
6. Click **Run** ✅

## Step 2: Google OAuth (2 minutes)

### Get Credentials
1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create/select project
3. Search & enable **Google+ API**
4. Go to **Credentials** → **Create OAuth 2.0 Client ID** (Web application)
5. Set URIs:
   - **JavaScript Origins**: `http://localhost:3000`
   - **Redirect URIs**: `http://localhost:3000/auth/callback`
6. Copy **Client ID** and **Client Secret**

### Configure Supabase
1. In Supabase → **Authentication** → **Providers**
2. Find **Google** → Enable it
3. Paste Client ID and Secret
4. Save ✅

## Step 3: Environment Variables (1 minute)

Create `.env.local` in your project root:

```bash
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

Get these from Supabase → Project Settings → API

## Step 4: Test It! (1 minute)

```bash
npm run dev
```

1. Go to `http://localhost:3000/login`
2. Click **"Sign in with Google"**
3. Complete Google auth
4. Go to a product page
5. Click **"Reviews"** or **"Q&A"** tab
6. Try submitting a review or question ✅

---

## 🎯 What Each File Does

| File | Purpose |
|------|---------|
| `app/login/page.js` | Enhanced login page with Google button |
| `app/auth/callback/page.js` | OAuth callback handler |
| `app/providers/AuthProvider.js` | Auth context (useAuth hook) |
| `components/ReviewForm.js` | Write review form |
| `components/ReviewsList.js` | Display and sort reviews |
| `components/ProductQA.js` | Q&A accordion |
| `app/api/reviews/[id]/route.js` | Review API (GET/POST) |
| `app/api/qa/[id]/route.js` | Q&A API (GET/POST) |
| `components/AdminPanel.js` | Admin review/Q&A management |
| `app/admin/reviews/page.js` | Admin dashboard page |

---

## 📝 Quick Command Reference

### Start Development
```bash
npm run dev
```

### View Supabase Data
```
Supabase Dashboard → SQL Editor
SELECT * FROM reviews;
SELECT * FROM product_qa;
SELECT * FROM profiles;
```

### Test in Postman
```
GET /api/reviews/1
POST /api/reviews/1
  Body: { title, body, rating }
  Header: Authorization: Bearer {token}
```

---

## ✅ Checklist

- [ ] Database schema executed
- [ ] Google OAuth credentials created
- [ ] Supabase provider configured
- [ ] Environment variables set
- [ ] App running (`npm run dev`)
- [ ] Login works
- [ ] Reviews display
- [ ] Q&A works
- [ ] Admin dashboard accessible (use @admin email)

---

## 🆘 Quick Fixes

**Issue: "Supabase not configured"**
→ Check .env.local has all 4 variables

**Issue: Login redirects to error page**
→ Verify Google OAuth redirect URI in console

**Issue: Reviews not saving**
→ Check user is signed in (useAuth hook)

**Issue: Admin panel says "Access Denied"**
→ Your email must contain "@admin" - edit component or create @admin account

---

## 🚀 You're Ready!

All features are now live:
- ✅ Google authentication
- ✅ Product reviews with ratings
- ✅ Helpful voting
- ✅ Product Q&A
- ✅ Admin management panel

Visit `/login` to start! 🎉

