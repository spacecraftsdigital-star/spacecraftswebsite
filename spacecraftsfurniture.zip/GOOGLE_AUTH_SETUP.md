# Google OAuth Setup for Supabase

## Step 1: Get Google OAuth Credentials

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project or select existing one
3. Enable **Google+ API**
4. Go to **Credentials** → Create OAuth 2.0 Client ID
5. Choose **Web application**
6. Add Authorized JavaScript Origins:
   - `http://localhost:3000` (development)
   - `https://yourdomain.com` (production)

7. Add Authorized redirect URIs:
   - `http://localhost:3000/auth/callback` (development)
   - `https://yourdomain.com/auth/callback` (production)
   - `https://<your-project>.supabase.co/auth/v1/callback` (from Supabase)

8. Copy **Client ID** and **Client Secret**

## Step 2: Configure in Supabase

1. Go to your Supabase project
2. Navigate to **Authentication** → **Providers**
3. Find **Google** and enable it
4. Paste your Google Client ID and Client Secret
5. Save

## Step 3: Configure Environment Variables

In your `.env.local` file:

```
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

## Step 4: Run SQL Schema

Execute the schema from `sql/auth_reviews_qa_schema.sql` in your Supabase SQL Editor.

This will create:
- Enhanced `profiles` table with additional fields
- `reviews` table for product reviews
- `product_qa` table for Q&A

All tables have RLS policies enabled automatically.

## Testing

1. Start your app: `npm run dev`
2. Go to `/login`
3. Click "Sign in with Google"
4. You'll be redirected to Google auth, then back to your app
5. Your user data will be saved in the `profiles` table

