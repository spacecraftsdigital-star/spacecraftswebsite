'use client'
import AdminReviewsPanel from './AdminReviewsPanel'

export default function AdminPage() {
  return (
    <div style={{ minHeight: '100vh', background: '#f9fafb' }}>
      <AdminReviewsPanel />
    </div>
  )
}
