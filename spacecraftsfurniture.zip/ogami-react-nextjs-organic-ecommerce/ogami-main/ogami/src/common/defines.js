export const API_URL = "https://ogami-api.herokuapp.com";
