# Product Images Required for Spacecrafts Furniture

## 📸 Image Requirements & Specifications

### General Specifications
- **Format**: JPG or WebP (WebP preferred for better compression)
- **Resolution**: Minimum 1200x1200px (for zoom functionality)
- **Aspect Ratio**: 1:1 (square) for product cards
- **File Size**: Max 500KB per image (after compression)
- **Background**: White or light neutral (for consistency)
- **Quality**: Professional product photography

---

## 🛋️ Required Product Images by Category

### LIVING ROOM - Sofas & Couches (3 products)

#### 1. Modern L-Shape Sofa with Storage
- `l-shape-sofa-1.jpg` - Front view showing full sofa
- `l-shape-sofa-2.jpg` - Storage compartment open
- `l-shape-sofa-3.jpg` - Side angle view
- `l-shape-sofa-4.jpg` - Close-up of fabric texture (optional)

#### 2. 3-Seater Recliner Sofa - Premium Leather
- `recliner-sofa-1.jpg` - Upright position, front view
- `recliner-sofa-2.jpg` - Reclined position
- `recliner-sofa-3.jpg` - Close-up of leather and stitching
- `recliner-sofa-4.jpg` - Side view (optional)

#### 3. Fabric Loveseat Sofa - Compact 2-Seater
- `loveseat-sofa-1.jpg` - Front view
- `loveseat-sofa-2.jpg` - 3/4 angle view
- `loveseat-sofa-3.jpg` - In room setting (lifestyle shot)

---

### BEDROOM - Beds & Frames (3 products)

#### 4. King Size Upholstered Bed with Hydraulic Storage
- `king-bed-1.jpg` - Front view with headboard
- `king-bed-2.jpg` - Storage compartment open (hydraulic system)
- `king-bed-3.jpg` - Side view
- `king-bed-4.jpg` - Bedroom lifestyle shot

#### 5. Solid Wood Queen Bed - Contemporary Platform
- `queen-bed-1.jpg` - Front view
- `queen-bed-2.jpg` - Side view showing wood grain
- `queen-bed-3.jpg` - 3/4 angle
- `queen-bed-4.jpg` - Close-up of wood finish

#### 6. Metal Bunk Bed for Kids
- `bunk-bed-1.jpg` - Full view assembled
- `bunk-bed-2.jpg` - Close-up of ladder and safety rails
- `bunk-bed-3.jpg` - Kids room lifestyle shot

---

### DINING ROOM (3 products)

#### 7. 6-Seater Solid Wood Dining Table Set
- `dining-set-6-1.jpg` - Full set from above angle
- `dining-set-6-2.jpg` - Side view with chairs
- `dining-set-6-3.jpg` - Close-up of wood grain and finish
- `dining-set-6-4.jpg` - Dining room lifestyle shot

#### 8. Modern Glass Top Dining Table - 4 Seater
- `glass-dining-4-1.jpg` - Top view
- `glass-dining-4-2.jpg` - Side view showing chrome base
- `glass-dining-4-3.jpg` - Modern dining room setting

#### 9. Buffet Cabinet - Sideboard Storage
- `buffet-cabinet-1.jpg` - Front view closed
- `buffet-cabinet-2.jpg` - Doors open showing interior
- `buffet-cabinet-3.jpg` - 3/4 angle view

---

### OFFICE FURNITURE (3 products)

#### 10. Ergonomic Executive Office Chair
- `office-chair-1.jpg` - Front view
- `office-chair-2.jpg` - Side view showing lumbar support
- `office-chair-3.jpg` - 360-degree rotation view
- `office-chair-4.jpg` - In office setting

#### 11. Computer Desk with Storage
- `computer-desk-1.jpg` - Front view
- `computer-desk-2.jpg` - Top view showing work surface
- `computer-desk-3.jpg` - With computer setup (lifestyle)

#### 12. L-Shaped Executive Desk
- `l-desk-1.jpg` - Full L-shape view
- `l-desk-2.jpg` - Corner detail
- `l-desk-3.jpg` - Home office setting

---

### STORAGE & ORGANIZATION (5 products)

#### 13. Modular Wardrobe System - 3 Door
- `wardrobe-3door-1.jpg` - Front view closed
- `wardrobe-3door-2.jpg` - Doors open showing interior organization
- `wardrobe-3door-3.jpg` - Mirror detail

#### 14. 5-Tier Bookshelf - Ladder Style
- `ladder-bookshelf-1.jpg` - Front view empty
- `ladder-bookshelf-2.jpg` - Styled with books and decor
- `ladder-bookshelf-3.jpg` - Side angle

#### 15. Shoe Rack Cabinet with Seating
- `shoe-rack-1.jpg` - Front view closed
- `shoe-rack-2.jpg` - Compartments open with shoes
- `shoe-rack-3.jpg` - In entryway setting

#### 16. Ottoman Storage Box
- `ottoman-1.jpg` - Closed view
- `ottoman-2.jpg` - Open showing storage interior
- `ottoman-3.jpg` - In living room setting

#### 17. Corner Shelf Unit - 5 Tier
- `corner-shelf-1.jpg` - Front view in corner
- `corner-shelf-2.jpg` - Styled with decor
- `corner-shelf-3.jpg` - Close-up of shelf detail

---

### CHAIRS & SEATING (5 products)

#### 18. Accent Chair with Ottoman - Velvet
- `accent-chair-1.jpg` - Chair and ottoman front view
- `accent-chair-2.jpg` - Close-up of velvet tufting
- `accent-chair-3.jpg` - In reading nook setting

#### 19. Set of 4 Dining Chairs
- `dining-chairs-4-1.jpg` - All 4 chairs in a row
- `dining-chairs-4-2.jpg` - Single chair detail
- `dining-chairs-4-3.jpg` - At dining table

#### 20. Bar Stools Set of 2
- `bar-stools-1.jpg` - Both stools front view
- `bar-stools-2.jpg` - Side view showing height adjustment
- `bar-stools-3.jpg` - At kitchen counter

#### 21. Rocking Chair with Cushion
- `rocking-chair-1.jpg` - Front view
- `rocking-chair-2.jpg` - Side view showing rocker
- `rocking-chair-3.jpg` - In nursery setting

#### 22. Gaming Chair with RGB
- `gaming-chair-1.jpg` - Front view with RGB lights on
- `gaming-chair-2.jpg` - Reclined position
- `gaming-chair-3.jpg` - Gaming setup

---

### TABLES (5 products)

#### 23. Coffee Table with Lift Top
- `coffee-table-1.jpg` - Closed position
- `coffee-table-2.jpg` - Lift-top raised
- `coffee-table-3.jpg` - Storage compartment view
- `coffee-table-4.jpg` - In living room

#### 24. Console Table - Marble Top
- `console-table-1.jpg` - Front view
- `console-table-2.jpg` - Close-up of marble top
- `console-table-3.jpg` - In entryway

#### 25. Side Table Set of 2 - Nesting
- `nesting-tables-1.jpg` - Nested together
- `nesting-tables-2.jpg` - Separated
- `nesting-tables-3.jpg` - In use beside sofa

---

### TV UNITS & ENTERTAINMENT (2 products)

#### 26. Contemporary TV Unit with LED
- `tv-unit-led-1.jpg` - Front view with LED lights on
- `tv-unit-led-2.jpg` - With TV mounted
- `tv-unit-led-3.jpg` - Drawer storage open

#### 27. Wooden TV Stand - Rustic
- `tv-stand-rustic-1.jpg` - Front view
- `tv-stand-rustic-2.jpg` - With TV and decor
- `tv-stand-rustic-3.jpg` - Wood texture detail

---

### OUTDOOR FURNITURE (2 products)

#### 28. Outdoor Patio Set - 4 Seater
- `patio-set-1.jpg` - Full set outdoor setting
- `patio-set-2.jpg` - Close-up of wicker detail
- `patio-set-3.jpg` - On balcony/patio

#### 29. Hammock with Stand
- `hammock-1.jpg` - Full setup
- `hammock-2.jpg` - Person relaxing (lifestyle)
- `hammock-3.jpg` - Close-up of stand

---

### MATTRESSES (2 products)

#### 30. Memory Foam Mattress - Queen
- `memory-foam-queen-1.jpg` - Top view
- `memory-foam-queen-2.jpg` - Cross-section showing layers
- `memory-foam-queen-3.jpg` - On bed frame

#### 31. Spring Mattress - King
- `spring-king-1.jpg` - Top view
- `spring-king-2.jpg` - Edge support detail
- `spring-king-3.jpg` - On bed lifestyle

---

### HOME DECOR (5 products)

#### 32. Wall Mirror - Full Length
- `wall-mirror-1.jpg` - Front view
- `wall-mirror-2.jpg` - Frame detail
- `wall-mirror-3.jpg` - In bedroom setting

#### 33. Table Lamp Set of 2
- `table-lamp-1.jpg` - Both lamps
- `table-lamp-2.jpg` - Single lamp lit
- `table-lamp-3.jpg` - On bedside table

#### 34. Floor Lamp - Arc Design
- `floor-lamp-1.jpg` - Full lamp
- `floor-lamp-2.jpg` - Close-up of base and shade
- `floor-lamp-3.jpg` - In living room

---

### KIDS FURNITURE (2 products)

#### 35. Study Table for Kids with Chair
- `kids-study-1.jpg` - Table and chair set
- `kids-study-2.jpg` - Child using (lifestyle)
- `kids-study-3.jpg` - Height adjustment feature

#### 36. Kids Storage Bench with Toy Box
- `kids-bench-1.jpg` - Closed
- `kids-bench-2.jpg` - Open with toys
- `kids-bench-3.jpg` - In playroom

---

### ADDITIONAL PRODUCTS (Continue pattern for remaining 14 products)

Follow the same naming convention and 3-4 images per product.

---

## 📂 File Organization

### Folder Structure in Supabase Storage

```
spacecraftsdigital/
├── products/
│   ├── sofas/
│   │   ├── l-shape-sofa-1.jpg
│   │   ├── l-shape-sofa-2.jpg
│   │   └── ...
│   ├── beds/
│   ├── dining/
│   ├── office/
│   ├── storage/
│   ├── chairs/
│   ├── tables/
│   ├── outdoor/
│   ├── mattresses/
│   ├── decor/
│   └── kids/
├── categories/
│   ├── sofas.jpg
│   ├── beds.jpg
│   ├── dining.jpg
│   └── ...
├── brands/
│   ├── spacecrafts-elite.png
│   └── ...
└── hero/
    ├── slide-1.jpg
    ├── slide-2.jpg
    └── slide-3.jpg
```

---

## 🎨 Image Sources & Alternatives

If you don't have professional product photography yet:

### Free Stock Photo Sites (Furniture)
1. **Unsplash** - https://unsplash.com/s/photos/furniture
2. **Pexels** - https://www.pexels.com/search/furniture/
3. **Pixabay** - https://pixabay.com/images/search/furniture/

### Paid Stock Photo Sites (Higher Quality)
1. **Shutterstock** - https://www.shutterstock.com
2. **Adobe Stock** - https://stock.adobe.com
3. **Getty Images** - https://www.gettyimages.com

### 3D Rendering Services (For Custom Products)
1. **Fiverr** - Product rendering services
2. **Upwork** - 3D furniture modeling
3. **CGTrader** - 3D models marketplace

---

## ✅ Image Optimization Checklist

Before uploading to Supabase:

- [ ] Resize to 1200x1200px minimum
- [ ] Compress using TinyPNG or ImageOptim
- [ ] Convert to WebP format (optional, Next.js handles this)
- [ ] Ensure white/neutral background
- [ ] Verify image quality and sharpness
- [ ] Add watermark if needed for protection
- [ ] Name files according to convention
- [ ] Organize into proper folders

---

## 🔄 Updating Database After Image Upload

After uploading all images to Supabase Storage, update the database:

```sql
-- Example: Update image URLs for a specific product
UPDATE product_images
SET url = 'https://oduvaeykaeabnpmyliut.supabase.co/storage/v1/object/public/spacecraftsdigital/products/sofas/l-shape-sofa-1.jpg'
WHERE product_id = (SELECT id FROM products WHERE slug = 'modern-l-shape-sofa-storage')
AND position = 0;

-- Repeat for all product images
```

Or use the admin panel to update image URLs through the UI.

---

## 📝 Notes

- **Placeholder images** are currently used with paths like `/products/[name].jpg`
- After uploading real images, update all URLs in the database
- Consider using a CDN (Cloudflare, Cloudinary) for better performance
- Implement lazy loading for images below the fold
- Use Next.js Image component which auto-optimizes images

---

**Need help with product photography?**
Contact: spacecraftsdigital@gmail.com
