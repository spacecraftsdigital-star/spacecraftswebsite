# Complete Implementation Guide - Authentication, Reviews & Q&A

## Overview

This guide covers the complete implementation of:
1. **Google OAuth Authentication** via Supabase
2. **Product Reviews System** with rating and helpful votes
3. **Product Q&A System** with admin replies
4. User profile management and data capture

---

## Part 1: Google OAuth Setup

### Step 1: Create Google OAuth Credentials

1. Go to [Google Cloud Console](https://console.cloud.google.com/)
2. Create a new project (or use existing)
3. Search for and enable **Google+ API**
4. Go to **Credentials** → **Create OAuth 2.0 Client ID**
5. Choose **Web application**
6. Configure **Authorized JavaScript origins**:
   ```
   http://localhost:3000
   https://yourdomain.com
   ```
7. Configure **Authorized redirect URIs**:
   ```
   http://localhost:3000/auth/callback
   https://yourdomain.com/auth/callback
   https://<your-project>.supabase.co/auth/v1/callback
   ```
8. Copy your **Client ID** and **Client Secret**

### Step 2: Configure Supabase

1. Go to your Supabase project dashboard
2. Navigate to **Authentication → Providers**
3. Find **Google** provider and enable it
4. Paste your Google Client ID and Client Secret
5. Save changes

### Step 3: Update Environment Variables

Create/update `.env.local`:

```bash
# Supabase
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key-here

# Site URL (for auth redirects)
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

### Step 4: Setup Database Schema

Execute the SQL from `sql/auth_reviews_qa_schema.sql` in your Supabase SQL Editor:

1. Go to Supabase Dashboard → SQL Editor
2. Create a new query
3. Paste content from `sql/auth_reviews_qa_schema.sql`
4. Run the query
5. This creates all necessary tables with RLS policies

---

## Part 2: File Structure

### New Files Created

```
app/
├── auth/
│   └── callback/
│       └── page.js                 # OAuth callback handler
├── login/
│   ├── page.js                     # Improved login page (UPDATED)
│   └── login.module.css            # Login styling
├── providers/
│   └── AuthProvider.js             # Auth context & hooks
└── api/
    ├── reviews/
    │   └── [id]/
    │       └── route.js            # Review API endpoints
    └── qa/
        └── [id]/
            └── route.js            # Q&A API endpoints

components/
├── ReviewForm.js                   # Write review form
├── ReviewForm.module.css
├── ReviewsList.js                  # Display reviews
├── ReviewsList.module.css
├── ProductQA.js                    # Q&A accordion
├── ProductQA.module.css
└── ProductDetailClient.js          # UPDATED with new components

lib/
├── supabaseClient.js               # Already exists (OK)

sql/
├── auth_reviews_qa_schema.sql      # NEW - Database schema
```

---

## Part 3: How It Works

### Authentication Flow

1. User clicks "Sign in with Google" on `/login`
2. Google OAuth dialog opens
3. After approval, redirects to `/auth/callback`
4. `AuthProvider` creates user profile in `profiles` table
5. User can now submit reviews and questions

### User Data Captured

From Google OAuth:
- Email
- Full Name
- Avatar URL

Additional fields you can add later:
- Phone
- Address
- City, State, Postal Code
- Country

### Reviews System

**Features:**
- Users can rate (1-5 stars) and write reviews
- Admin approval workflow (reviews start as "pending")
- Helpful/Unhelpful voting system
- Sort reviews by: Recent, Helpful, Highest, Lowest ratings
- Verified purchase badges (can be manually set by admin)

**Database:**
- `reviews` - Stores review data
- `review_votes` - Tracks helpful/unhelpful votes

**API Endpoints:**
- `GET /api/reviews/[productId]` - Fetch reviews
- `POST /api/reviews/[productId]` - Submit review

### Q&A System

**Features:**
- Users ask questions about products
- Admin (users with @admin email) can reply
- Accordion-style UI (expand to see answer)
- Answered questions show first
- Track view counts

**Database:**
- `product_qa` - Stores questions and answers

**API Endpoints:**
- `GET /api/qa/[productId]` - Fetch Q&A
- `POST /api/qa/[productId]` - Post question

---

## Part 4: Component Usage

### In Product Pages

The `ProductDetailClient` component now includes:

```jsx
<ReviewForm productId={product.id} onReviewSubmitted={() => {}} />
<ReviewsList productId={product.id} />
<ProductQA productId={product.id} />
```

These are automatically displayed in the "Reviews" and "Q&A" tabs.

### Using Auth Hook

In any component:

```jsx
'use client'
import { useAuth } from '@/app/providers/AuthProvider'

export default function MyComponent() {
  const { user, profile, isAuthenticated, signOut } = useAuth()
  
  if (!isAuthenticated) {
    return <p>Please sign in</p>
  }
  
  return (
    <div>
      Welcome, {profile?.full_name}!
      <button onClick={signOut}>Sign Out</button>
    </div>
  )
}
```

---

## Part 5: Admin Features (Server-Side)

### Approving Reviews

Create an admin dashboard that queries reviews with status = 'pending':

```sql
SELECT * FROM reviews WHERE status = 'pending' ORDER BY created_at;
```

Update status to 'approved':

```sql
UPDATE reviews SET status = 'approved' WHERE id = 123;
```

### Replying to Questions

Using Supabase client with service role:

```javascript
const supabase = createSupabaseServerClient()

const { data, error } = await supabase
  .from('product_qa')
  .update({
    answer: 'Your answer here',
    answer_by: adminUserId,
    answered_at: new Date()
  })
  .eq('id', qaId)
```

---

## Part 6: Testing

### Test Google Login

1. Start your app: `npm run dev`
2. Go to `http://localhost:3000/login`
3. Click "Sign in with Google"
4. Complete Google auth
5. Should be redirected to `/account`
6. Check Supabase `profiles` table - your profile should be created

### Test Reviews

1. Sign in with Google
2. Go to a product page
3. Click "Reviews" tab
4. Fill in review form
5. Click "Submit Review"
6. Your review should appear (pending approval by default)

### Test Q&A

1. Sign in with Google
2. Go to a product page
3. Click "Q&A" tab
4. Click "+ Ask a Question"
5. Enter question and submit
6. Question should appear immediately

---

## Part 7: Customization

### Change Review Approval Workflow

To auto-approve reviews, in `app/api/reviews/[id]/route.js`:

```javascript
status: 'approved'  // Change from 'pending'
```

### Add More User Fields

In `sql/auth_reviews_qa_schema.sql`, add columns to `profiles`:

```sql
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS phone text;
ALTER TABLE profiles ADD COLUMN IF NOT EXISTS age int;
-- etc.
```

Then update user when they update profile:

```javascript
const { useAuth } = require('@/app/providers/AuthProvider')

const { updateProfile } = useAuth()
await updateProfile({ phone: '9876543210' })
```

### Customize Email Notifications

Add email notification logic in API routes when:
- Review is submitted (notify admins)
- Review is approved (notify user)
- Question is answered (notify user)

---

## Part 8: Security Notes

⚠️ **Important:**

1. **Never expose SUPABASE_SERVICE_ROLE_KEY** in frontend code
2. Service role key is only used in server routes (`/api`) with `createSupabaseServerClient()`
3. RLS (Row Level Security) is enabled on all tables - users can only see/edit their own data
4. Admin actions require email check (simplistic - add proper role system in production)

---

## Part 9: Troubleshooting

### "Unauthorized" errors

- Make sure user is signed in
- Check that auth token is passed in `Authorization` header
- Verify Supabase session is active

### Reviews/Q&A not showing

- Check RLS policies are created (from schema.sql)
- Verify reviews have `status = 'approved'`
- Check that product_id matches

### Google Login Redirect Issues

- Verify redirect URI in Google Console matches your app URL
- Check `NEXT_PUBLIC_SITE_URL` environment variable
- Make sure Supabase Google provider is enabled

---

## Next Steps

1. ✅ Complete Google OAuth setup (see Part 1)
2. ✅ Run database schema SQL (see Part 4)
3. ✅ Test login flow
4. ✅ Test reviews submission
5. ✅ Create admin dashboard for review approval
6. ✅ Add email notifications
7. ✅ Implement proper admin role system
8. ✅ Add more user profile fields as needed

---

For questions or issues, check the [Supabase Auth Docs](https://supabase.com/docs/guides/auth/social-oauth) and [Next.js Docs](https://nextjs.org/docs).

