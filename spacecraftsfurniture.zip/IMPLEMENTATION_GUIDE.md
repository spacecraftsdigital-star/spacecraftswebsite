# Spacecrafts Furniture - E-Commerce Platform
## Modern Furniture Store with Next.js, Supabase & Stripe

![Spacecrafts Furniture](./public/og-image.jpg)

## 🚀 Project Overview

Spacecrafts Furniture is a premium, SEO-optimized e-commerce platform for selling furniture online. Built with modern web technologies and inspired by the Ogami template design principles.

### ✨ Key Features

- 🛋️ **Premium Furniture Catalog** - 50+ curated products across 15 categories
- 🔐 **Secure Authentication** - User accounts with Supabase Auth
- 🛒 **Shopping Cart & Wishlist** - Seamless shopping experience
- 💳 **Stripe Payment Integration** - Secure checkout process
- 📱 **Fully Responsive** - Mobile-first design approach
- 🎨 **Modern UI/UX** - Inspired by Ogami template with Framer Motion animations
- 🔍 **SEO Optimized** - Comprehensive metadata, sitemaps, and structured data
- 📊 **Google Analytics & GTM** - Complete tracking setup
- 🏪 **Store Locator** - Multiple physical store locations
- ⚡ **Performance Optimized** - Next.js 14 with image optimization
- 🌐 **Multi-language Ready** - Internationalization support structure

---

## 📋 Table of Contents

1. [Tech Stack](#tech-stack)
2. [Prerequisites](#prerequisites)
3. [Installation](#installation)
4. [Database Setup](#database-setup)
5. [Configuration](#configuration)
6. [Running the Project](#running-the-project)
7. [Project Structure](#project-structure)
8. [Features Guide](#features-guide)
9. [SEO Implementation](#seo-implementation)
10. [Deployment](#deployment)
11. [Product Data](#product-data)

---

## 🛠️ Tech Stack

### Frontend
- **Next.js 14** - React framework with App Router
- **React 18** - UI library
- **Framer Motion** - Animations
- **React Slick** - Carousels
- **React Icons** - Icon library

### Backend & Database
- **Supabase** - Backend as a Service (PostgreSQL)
- **Supabase Auth** - Authentication
- **Supabase Storage** - File storage for product images

### Payments
- **Stripe** - Payment processing
- **Stripe Checkout** - Hosted checkout pages

### Analytics & Marketing
- **Google Tag Manager** - Tag management
- **Google Analytics 4** - Analytics tracking
- **Google Ads** - Conversion tracking
- **SendGrid** - Email notifications

### Development Tools
- **ESLint** - Code linting
- **Sharp** - Image optimization
- **Bundle Analyzer** - Performance analysis

---

## 📦 Prerequisites

Before you begin, ensure you have:

- **Node.js** 18.x or higher
- **npm** or **yarn** package manager
- **Supabase Account** - [Sign up here](https://supabase.com)
- **Stripe Account** - [Sign up here](https://stripe.com)
- **Google Tag Manager** (optional) - For analytics
- **SendGrid API Key** (optional) - For emails

---

## 🔧 Installation

### 1. Clone the Repository

```bash
git clone https://github.com/yourusername/spacecrafts-furniture.git
cd spacecrafts-furniture
```

### 2. Install Dependencies

```bash
npm install
# or
yarn install
```

---

## 🗄️ Database Setup

### Step 1: Create Supabase Project

1. Go to [Supabase Dashboard](https://app.supabase.com)
2. Create a new project
3. Note your project URL and API keys

### Step 2: Run Database Schema

1. Open Supabase SQL Editor
2. Copy and paste the content from `sql/schema.sql`
3. Execute the SQL

### Step 3: Populate with Furniture Data

1. Open Supabase SQL Editor again
2. Copy and paste the content from `sql/furniture_products_data.sql`
3. Execute the SQL
4. This will create:
   - ✅ 15 furniture categories
   - ✅ 10 premium brands
   - ✅ 50 detailed products
   - ✅ Sample product images (URLs to update)
   - ✅ 6 store locations across India
   - ✅ Sample customer reviews
   - ✅ Search functions and views

### Step 4: Set Up Row Level Security (RLS)

Run the policies from `sql/rls_policies.sql` to secure your data.

### Step 5: Upload Product Images

1. Go to Supabase Storage
2. Create a bucket named `spacecraftsdigital` (public)
3. Upload product images to `products/` folder
4. Update image URLs in the database

---

## ⚙️ Configuration

### Environment Variables

Create a `.env.local` file in the root directory. Use the template below:

```env
# Supabase Configuration
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
SUPABASE_STORAGE_BUCKET=spacecraftsdigital

# Stripe Configuration
NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_SECRET_KEY=sk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...

# Site Configuration
NEXT_PUBLIC_SITE_URL=https://spacecraftsfurniture.com
NEXT_PUBLIC_SITE_NAME=Spacecrafts Furniture

# Google Tag Manager (Optional)
NEXT_PUBLIC_GTM_ID=GTM-XXXXXXX

# Google Analytics 4 (Optional)
GA4_MEASUREMENT_ID=G-XXXXXXXXXX
GA4_API_SECRET=your-api-secret

# SendGrid Email (Optional)
SENDGRID_API_KEY=SG.xxxxxxxxxxxxx
EMAIL_FROM=noreply@spacecraftsfurniture.com
```

### Update Configuration Files

1. **Next.js Config**: Already configured in `next.config.js`
2. **Robots.txt**: Update domain in `public/robots.txt`
3. **Sitemap**: Update domain in `app/sitemap.xml/route.js`

---

## 🚀 Running the Project

### Development Mode

```bash
npm run dev
```

Visit [http://localhost:3000](http://localhost:3000)

### Production Build

```bash
npm run build
npm run start
```

### Analyze Bundle Size

```bash
npm run analyze
```

---

## 📁 Project Structure

```
spacecraftsfurniture/
├── app/                          # Next.js App Router
│   ├── layout.js                 # Root layout with SEO
│   ├── page.js                   # Homepage
│   ├── products/                 # Product pages
│   ├── cart/                     # Shopping cart
│   ├── checkout/                 # Checkout process
│   ├── account/                  # User account
│   ├── orders/                   # Order history
│   └── api/                      # API routes
│       ├── create-checkout-session/  # Stripe checkout
│       ├── stripe-webhook/       # Stripe webhooks
│       └── upload-image/         # Image upload
├── components/                   # React components
│   ├── ModernHeroCarousel.js     # Hero slider
│   ├── ModernCategoryGrid.js     # Category display
│   ├── FeaturedProductsSection.js # Featured products
│   ├── ProductCard.js            # Product card
│   ├── Header.js                 # Site header
│   ├── ModernFooter.js           # Site footer
│   └── ...                       # Other components
├── lib/                          # Utility libraries
│   ├── supabaseClient.js         # Supabase client
│   ├── stripe.js                 # Stripe client
│   ├── analytics.js              # Analytics helpers
│   └── googleAds.js              # Google Ads tracking
├── public/                       # Static assets
│   ├── robots.txt                # SEO robots file
│   ├── categories/               # Category images
│   ├── brands/                   # Brand logos
│   └── hero/                     # Hero slider images
├── sql/                          # Database scripts
│   ├── schema.sql                # Database schema
│   ├── furniture_products_data.sql # Sample data
│   └── rls_policies.sql          # Security policies
├── styles/                       # Global styles
├── .env.local                    # Environment variables
├── next.config.js                # Next.js configuration
└── package.json                  # Dependencies
```

---

## 🎯 Features Guide

### 1. User Authentication
- Sign up / Sign in with Supabase Auth
- Password reset functionality
- Protected routes for user-specific pages

### 2. Product Catalog
- Browse products by category
- Search functionality
- Filter by price, brand, rating
- Product detail pages with image gallery

### 3. Shopping Cart
- Add/remove products
- Update quantities
- Persistent cart (stored in database)
- Cart summary with totals

### 4. Checkout Process
- Address management
- Stripe payment integration
- Order confirmation
- Email notifications (SendGrid)

### 5. User Account
- Order history
- Wishlist
- Profile management
- Saved addresses

### 6. Admin Features
- Product management (CRUD operations)
- Order management
- Protected admin routes

---

## 🔍 SEO Implementation

### Metadata & Structure

✅ **Dynamic Metadata**: Every page has unique title, description, and OG tags
✅ **Structured Data**: JSON-LD for products, organization, breadcrumbs
✅ **Canonical URLs**: Proper canonical tags to avoid duplicate content
✅ **Image Alt Text**: All images have descriptive alt attributes
✅ **Semantic HTML**: Proper heading hierarchy (H1, H2, H3)

### Performance

✅ **Image Optimization**: Next.js Image component with WebP/AVIF
✅ **Code Splitting**: Automatic code splitting by Next.js
✅ **Lazy Loading**: Components load on demand
✅ **Caching**: Proper cache headers for static assets

### Technical SEO

✅ **Sitemap.xml**: Auto-generated from database
✅ **Robots.txt**: Configured for optimal crawling
✅ **Mobile-First**: Fully responsive design
✅ **Core Web Vitals**: Optimized for LCP, FID, CLS

### Content SEO

✅ **Keyword-Rich Content**: Products have detailed descriptions
✅ **Internal Linking**: Proper link structure between pages
✅ **Breadcrumbs**: Navigation breadcrumbs for UX and SEO
✅ **Rich Snippets**: Product schema for search results

---

## 🌐 Deployment

### Vercel (Recommended)

1. Push code to GitHub
2. Import project to Vercel
3. Add environment variables
4. Deploy!

```bash
vercel
```

### Other Platforms

- **Netlify**: Compatible with Next.js
- **AWS Amplify**: Supports Next.js SSR
- **Self-hosted**: Use PM2 or Docker

### Post-Deployment Checklist

- [ ] Update `.env.local` with production URLs
- [ ] Configure Stripe webhooks
- [ ] Set up custom domain
- [ ] Enable SSL certificate
- [ ] Submit sitemap to Google Search Console
- [ ] Configure CDN for images
- [ ] Set up monitoring (Sentry, LogRocket)

---

## 📊 Product Data

### Furniture Categories

1. **Living Room** (Sofas, Couches, TV Units)
2. **Bedroom** (Beds, Mattresses, Wardrobes)
3. **Dining Room** (Tables, Chairs, Buffets)
4. **Office Furniture** (Desks, Chairs, Storage)
5. **Outdoor Furniture** (Patio Sets, Hammocks)
6. **Storage & Organization** (Cabinets, Shelves)
7. **Kids Furniture** (Beds, Study Tables)
8. **Home Decor** (Mirrors, Lamps, Accessories)

### Product Details Included

Each product has:
- High-quality images (3-5 per product)
- Detailed descriptions (SEO-optimized)
- Specifications (dimensions, material, warranty)
- Pricing with discounts
- Stock availability
- Customer ratings and reviews
- Delivery information
- Brand information

### Adding More Products

Use the template in `sql/furniture_products_data.sql` to add more products. Each product should include:

```sql
INSERT INTO products (name, slug, category_id, brand_id, description, price, discount_price, stock, rating, review_count, dimensions, material, warranty, delivery_info, tags)
VALUES
('Product Name', 'product-slug', category_id, brand_id, 'SEO-rich description...', 49999.00, 39999.00, 20, 4.5, 120, '{"width":200}', 'Material', '2 years', 'Delivery info', ARRAY['tag1','tag2']);
```

---

## 🤝 Support & Contact

For questions or support:

- 📧 Email: spacecraftsdigital@gmail.com
- 📞 Phone: +91-80-2512-3456
- 🌐 Website: https://spacecraftsfurniture.com

---

## 📝 License

This project is proprietary and confidential. © 2024 Spacecrafts Furniture. All rights reserved.

---

## 🎉 Next Steps

1. ✅ Run `npm install`
2. ✅ Set up Supabase and run SQL scripts
3. ✅ Configure `.env.local`
4. ✅ Upload product images
5. ✅ Test locally with `npm run dev`
6. ✅ Deploy to Vercel
7. ✅ Configure domain and SSL
8. ✅ Submit to search engines

---

**Built with ❤️ by Spacecrafts Digital**
